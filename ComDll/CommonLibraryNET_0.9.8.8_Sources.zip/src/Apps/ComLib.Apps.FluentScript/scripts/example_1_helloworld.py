﻿
println hello word! without using quotes - fs with types

println this prints all the text after the print keyword up to the end of line
