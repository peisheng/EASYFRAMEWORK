﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ComLib.Web.Lib.Services;


namespace ComLib.Web.Lib.Services.Information
{  
    /// <summary>
    /// Attribute used to define a widget.
    /// </summary>
    public class InfoMetaData : Extension
    {
    }
}
